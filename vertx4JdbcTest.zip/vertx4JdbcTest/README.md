# Test new Vertx SqlClient

With Vertx 4.x comes a new _Sql Client API_, which takes into account existing asynchronous driver for Postgres, MySql, DB2 (with 4.0.3 MSSql). As JDBC connection pool manager Agroal is used instead of C3P0. Because the _Legacy JDBC Client_ is deprecated and will only be supported in Vertx 4.x, we have to migrate in the mean term. _The JDBC Client API_ that we used so far is now deprecated and will be removed in the next major Vertx release. We used the _Sql Client API_ in a prototypical implementation of the _ResultEnhancerService_ and it works well with Postgres. In order to verify, that it works with Oracle too, we provide this simple test.

To do:
1. Set appropriate values for user, password, jdbcUrl and queryString in de.test.Vertx4JdbcTest.java
2. mvn clean install
3. java -jar target/vertx4-jdbc-test-1.0.0-fat.jar

If the Agroal jdbcPool-implementation works for Oracle, one or more lines will be displayed.
