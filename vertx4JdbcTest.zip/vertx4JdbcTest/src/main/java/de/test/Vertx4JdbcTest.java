/**
 * This code was developed in the cooperation project "Vernetzte Sicherheit" between Fraunhofer FOKUS and the German Federal Ministry of Interior
 * under the project code ÖS I 3 - 43002/1#2
 * Copyright 2014-2021 Fraunhofer FOKUS
 * This source code is licensed under Creative Commons Attribution-NonCommercial 4.0 International license. 
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 * http://creativecommons.org/licenses/by-nc/4.0/
 * Unless required by applicable law or agreed to in
 * writing, software distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 */

package de.test;

import java.util.concurrent.atomic.AtomicReference;

import io.agroal.api.configuration.AgroalDataSourceConfiguration;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonArray;
import io.vertx.jdbcclient.JDBCConnectOptions;
import io.vertx.jdbcclient.JDBCPool;
import io.vertx.sqlclient.Tuple;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowStream;
import io.vertx.sqlclient.SqlConnection;



/**
 * Search micro service 
 * 
 * @author ulrich.kriegel@fokus.fraunhofer.de
 *
 */
public class Vertx4JdbcTest extends AbstractVerticle {
	
	

	
	


	

	@Override
	public void start(Promise<Void> startPromise) {
		// Identify service
		String user = "adep";
		String password = "adep";
		String jdbcUrl = "jdbc:postgresql://localhost:5433/adep-test-phonetics";
		String queryString = "SELECT * from person where technical_id = ?";
		String id = "0815";
		
		AtomicReference<SqlConnection> connRef =  new AtomicReference<SqlConnection>();
		try {	
			

				JDBCPool jdbcPool = JDBCPool.pool(vertx,
							new JDBCConnectOptions()
							.setUser(user)
							.setPassword(password)
							.setJdbcUrl(jdbcUrl)
							.setDataSourceImplementation(AgroalDataSourceConfiguration.DataSourceImplementation.AGROAL.name())
							,
							new PoolOptions().setMaxSize(20)
							);

				jdbcPool.getConnection()
				.onFailure(t->{
					System.out.println("connection error: "+t);
					startPromise.fail(t);
					return;
				})
				.compose(conn->{
					connRef.set(conn);
					return conn.prepare(queryString);
				})
				.onSuccess(prep->{
					JsonArray resultArray = new JsonArray();
					RowStream<Row> stream = prep.createStream(50,Tuple.of(id));
					stream
					.exceptionHandler(e->{
						System.out.println("stream error " + e);
						startPromise.fail(e);
						return;
					})
					.handler(row->{
						resultArray.add(row.toJson());
					})
					.endHandler(v->{
						resultArray.forEach(j->System.out.println(j));
						connRef.get().close();
						vertx.close();
						startPromise.complete();
						return;

					});
				}).onFailure(t->{
					startPromise.fail(t);
				});
		}catch(Throwable t) {
			System.out.println("error: "+t);
			startPromise.fail(t);
		}
		
	}
	


	@Override
	public void stop(Promise<Void> stopPromise){
		stopPromise.complete();
	}
	
}
